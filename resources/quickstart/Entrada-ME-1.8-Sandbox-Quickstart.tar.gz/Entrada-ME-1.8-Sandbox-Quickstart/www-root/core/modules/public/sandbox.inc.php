<?php
/**
 * Entrada [ http://www.entrada-project.org ]
 */

if (!defined("PARENT_INCLUDED")) {
    exit;
} elseif (!isset($_SESSION["isAuthorized"]) || !(bool) $_SESSION["isAuthorized"]) {
    header("Location: " . ENTRADA_URL);
    exit;
} elseif (!$ENTRADA_ACL->amIAllowed("sandbox", "read")) {
    add_error("Your account does not have the permissions required to use this module.");

    echo display_error();

    application_log("error", "Group [" . $ENTRADA_USER->getActiveGroup() . "] and role [" . $ENTRADA_USER->getActiveRole() . "] do not have access to this module [" . $MODULE . "]");
} else {
    /*
     * Updates the <title></title> of the page.
     */
    $PAGE_META["title"] = $translate->_("Public Sandbox");

    /*
     * Adds a breadcrumb to the breadcrumb trail.
     */
    $BREADCRUMB[] = array("url" => ENTRADA_RELATIVE . "/sandbox", "title" => $translate->_("Public Sandbox"));

    /*
     * Renders the sandbox sidebar View Helper.
     */
    $sidebar = new Views_Sandbox_Sidebar();
    $sidebar->render();
    ?>

    <h1><?php echo $translate->_("Public Sandbox"); ?></h1>

    <?php
    /*
     * Models_Sandbox::fetchAllRecords() will return all non-deleted records from the sandboxes table as an array of objects.
     */
    $results = Models_Sandbox::fetchAllRecords();
    if ($results) {
        foreach ($results as $result) {
            echo "<div id=\"sandbox-" . $result->getID() . "\" class=\"sandboxes space-above space-below\">";
            echo "  <h3>" . html_encode($result->getTitle()) . "</h3>";
            echo    html_encode($result->getDescription());
            echo "</div>";
            echo "<hr />";
        }
    }
}
