<?php
/**
 * Entrada [ http://www.entrada-project.org ]
 *
 * Entrada is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Entrada is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Entrada.  If not, see <http://www.gnu.org/licenses/>.
 *
 * A model for the sandbox table.
 *
 * @author Organisation: Queen's University
 * @author Developer: Matt Simpson <simpson@queensu.ca>
 * @copyright Copyright 2017 Queen's University. All Rights Reserved.
 */

class Models_Sandbox extends Models_Base {
    protected $id, $title, $description, $created_date, $created_by, $updated_date, $updated_by, $deleted_date, $deleted_by;

    protected static $database_name = DATABASE_NAME; // (DATABASE_NAME, AUTH_DATABASE, or CLERKSHIP_DATABASE)

    protected static $table_name = "sandbox";

    protected static $primary_key = "id";

    protected static $default_sort_column = "title";

    protected static $default_sort_order = "ASC";

    public function __construct($arr = NULL) {
        parent::__construct($arr);
    }

    public function getID() {
        return $this->id;
    }

    public function getTitle() {
        return $this->title;
    }

    public function getDescription() {
        return $this->description;
    }

    public function getCreatedDate() {
        return $this->created_date;
    }

    public function getCreatedBy() {
        return $this->created_by;
    }

    public function getUpdatedDate() {
        return $this->updated_date;
    }

    public function getUpdatedBy() {
        return $this->updated_by;
    }

    public function getDeletedDate() {
        return $this->deleted_date;
    }

    public function getDeletedBy() {
        return $this->deleted_by;
    }

    /**
     * Method to provide delete functionality for the sandbox module. Note that Models_Base
     * does not have a delete() method because historically there was not a standard for delete
     * action. We have everything ranging from DELETE queries, to active fields, to the latest
     * standard of having a deleted_date column. Each model should implement its own delete()
     * method as appropriate.
     *
     * @param array $ids
     * @return mixed
     */
    public function delete($ids = array()) {
        global $db, $ENTRADA_USER;

        /*
         * This will allow us to delete either the current record or provide an array
         * of multiple ids to delete in a single query.
         */
        if (empty($ids) && $this->getID()) {
            $ids = array($this->getID());
        }

        $deleted = array(
            "deleted_date" => time(),
            "deleted_by" => $ENTRADA_USER->getID()
        );

        return $db->AutoExecute(static::$table_name, $deleted, "UPDATE", "id IN (" . implode(", ", $ids) . ")");
    }

    public static function fetchRowByID($id) {
        $self = new self();
        return $self->fetchRow(array(
            array("key" => "id", "method" => "=", "value" => $id)
        ));
    }

    public static function fetchRecords($ids = array()) {
        if (is_array($ids) && !empty($ids)) {
            $self = new self();
            return $self->fetchAll(array(array("key" => "id", "method" => "IN", "value" => $ids)));
        }
    }

    public static function fetchAllRecords() {
        $self = new self();
        return $self->fetchAll(array(array("key" => "deleted_date", "method" => "IS", "value" => NULL)));
    }
}